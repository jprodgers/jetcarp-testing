-- DuckDB views over JETCARP pack version sha256:9c9c7b4875e2d546e218cfc9f3a4c4212e4d9002b57a03ed98f0ff0adc172017 (feed rc-framework).
-- Not part of the format: run `duckdb -init views.sql` in this folder, or replace
-- the paths with this folder's URL to query a pack in place over HTTPS.
CREATE OR REPLACE VIEW annotations AS SELECT * FROM read_parquet(['tables/annotations/part-000001.parquet'], union_by_name = true);
CREATE OR REPLACE VIEW patterns AS SELECT * FROM read_parquet(['tables/patterns/class_group=oscillator/tiling_group=hex/part-000001.parquet', 'tables/patterns/class_group=oscillator/tiling_group=square/part-000001.parquet', 'tables/patterns/class_group=spaceship/tiling_group=square/part-000001.parquet', 'tables/patterns/class_group=still_life/tiling_group=hex/part-000001.parquet', 'tables/patterns/class_group=still_life/tiling_group=square/part-000001.parquet'], union_by_name = true);
CREATE OR REPLACE VIEW provenance AS SELECT * FROM read_parquet(['tables/provenance/part-000001.parquet'], union_by_name = true);
CREATE OR REPLACE VIEW rules AS SELECT * FROM read_parquet(['tables/rules/part-000001.parquet'], union_by_name = true);
CREATE OR REPLACE VIEW sightings AS SELECT * FROM read_parquet(['tables/sightings/part-000001.parquet'], union_by_name = true);
CREATE OR REPLACE VIEW tilings AS SELECT * FROM read_parquet(['tables/tilings/part-000001.parquet'], union_by_name = true);
CREATE OR REPLACE VIEW verifications AS SELECT * FROM read_parquet(['tables/verifications/part-000001.parquet'], union_by_name = true);
CREATE OR REPLACE VIEW runs_39fd769d_bfa3_492f_bcb3_1ffd617e203e AS SELECT * FROM read_parquet(['searches/39fd769d-bfa3-492f-bcb3-1ffd617e203e/runs/part-000001.parquet']);
