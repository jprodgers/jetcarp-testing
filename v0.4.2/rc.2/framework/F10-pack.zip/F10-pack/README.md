# rc.2 test, Framework



- Feed: `rc-framework`, version -, made 2026-11-15T16:31:46Z
- Version id (manifest hash): `sha256:9c9c7b4875e2d546e218cfc9f3a4c4212e4d9002b57a03ed98f0ff0adc172017`
- Publisher key: `SHA256:zi5e+Z5B9laOKqkjWJry2p33M8K6Gf6Qz1Dz8QRutRE`
- Licence: CC0-1.0
- Creators: RC tester (Framework)

This is an export of a JETCARP pack (format jetcarp-pack 1.0). Every table is a Parquet
file under `tables/`, and `pack.json` is the manifest: its SHA-256 is the version id
above, and the indexes in `index/` give the SHA-256 of every file. The format is
described in the JETCARP book's *Pack format* reference.

## Tables

- `annotations`: 20 rows in 1 part
- `patterns`: 341 rows in 5 parts
- `provenance`: 341 rows in 1 part
- `rules`: 3 rows in 1 part
- `sightings`: 441 rows in 1 part
- `tilings`: 2 rows in 1 part
- `verifications`: 441 rows in 1 part
