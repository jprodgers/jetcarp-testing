# rc.2 test, Acer



- Feed: `rc-acer`, version -, made 2026-11-15T14:34:14Z
- Version id (manifest hash): `sha256:c2408726b9cbf467f11980dd656081c629b73c2062d226ad08b4f204f626e147`
- Publisher key: `SHA256:oC9mdMytqshtIBqNgKOn9GksxuiFUwsNnxRBGLBaIo4`
- Licence: CC0-1.0
- Creators: RC tester (Acer)

This is an export of a JETCARP pack (format jetcarp-pack 1.0). Every table is a Parquet
file under `tables/`, and `pack.json` is the manifest: its SHA-256 is the version id
above, and the indexes in `index/` give the SHA-256 of every file. The format is
described in the JETCARP book's *Pack format* reference.

## Tables

- `annotations`: 23 rows in 1 part
- `patterns`: 113 rows in 5 parts
- `provenance`: 113 rows in 1 part
- `rules`: 3 rows in 1 part
- `sightings`: 202 rows in 1 part
- `tilings`: 2 rows in 1 part
- `verifications`: 128 rows in 1 part
