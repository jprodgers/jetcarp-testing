-- DuckDB views over JETCARP pack version sha256:c2408726b9cbf467f11980dd656081c629b73c2062d226ad08b4f204f626e147 (feed rc-acer).
-- Not part of the format: run `duckdb -init views.sql` in this folder, or replace
-- the paths with this folder's URL to query a pack in place over HTTPS.
CREATE OR REPLACE VIEW annotations AS SELECT * FROM read_parquet(['tables/annotations/part-000001.parquet'], union_by_name = true);
CREATE OR REPLACE VIEW patterns AS SELECT * FROM read_parquet(['tables/patterns/class_group=oscillator/tiling_group=hex/part-000001.parquet', 'tables/patterns/class_group=oscillator/tiling_group=square/part-000001.parquet', 'tables/patterns/class_group=spaceship/tiling_group=square/part-000001.parquet', 'tables/patterns/class_group=still_life/tiling_group=hex/part-000001.parquet', 'tables/patterns/class_group=still_life/tiling_group=square/part-000001.parquet'], union_by_name = true);
CREATE OR REPLACE VIEW provenance AS SELECT * FROM read_parquet(['tables/provenance/part-000001.parquet'], union_by_name = true);
CREATE OR REPLACE VIEW rules AS SELECT * FROM read_parquet(['tables/rules/part-000001.parquet'], union_by_name = true);
CREATE OR REPLACE VIEW sightings AS SELECT * FROM read_parquet(['tables/sightings/part-000001.parquet'], union_by_name = true);
CREATE OR REPLACE VIEW tilings AS SELECT * FROM read_parquet(['tables/tilings/part-000001.parquet'], union_by_name = true);
CREATE OR REPLACE VIEW verifications AS SELECT * FROM read_parquet(['tables/verifications/part-000001.parquet'], union_by_name = true);
CREATE OR REPLACE VIEW runs_5cbba190_5548_46c8_bf58_4ed39e19b932 AS SELECT * FROM read_parquet(['searches/5cbba190-5548-46c8-bf58-4ed39e19b932/runs/part-000001.parquet']);
