-- DuckDB views over JETCARP pack version sha256:092bf24ebf79a4663ba905ccd04147f5ea9003df9bb70fdd44bf4fd77acf112d (feed rc-mac).
-- Not part of the format: run `duckdb -init views.sql` in this folder, or replace
-- the paths with this folder's URL to query a pack in place over HTTPS.
CREATE OR REPLACE VIEW annotations AS SELECT * FROM read_parquet(['tables/annotations/part-000001.parquet'], union_by_name = true);
CREATE OR REPLACE VIEW patterns AS SELECT * FROM read_parquet(['tables/patterns/class_group=oscillator/tiling_group=hex/part-000001.parquet', 'tables/patterns/class_group=oscillator/tiling_group=square/part-000001.parquet', 'tables/patterns/class_group=spaceship/tiling_group=square/part-000001.parquet', 'tables/patterns/class_group=still_life/tiling_group=hex/part-000001.parquet', 'tables/patterns/class_group=still_life/tiling_group=square/part-000001.parquet'], union_by_name = true);
CREATE OR REPLACE VIEW provenance AS SELECT * FROM read_parquet(['tables/provenance/part-000001.parquet'], union_by_name = true);
CREATE OR REPLACE VIEW rules AS SELECT * FROM read_parquet(['tables/rules/part-000001.parquet'], union_by_name = true);
CREATE OR REPLACE VIEW sightings AS SELECT * FROM read_parquet(['tables/sightings/part-000001.parquet'], union_by_name = true);
CREATE OR REPLACE VIEW tilings AS SELECT * FROM read_parquet(['tables/tilings/part-000001.parquet'], union_by_name = true);
CREATE OR REPLACE VIEW verifications AS SELECT * FROM read_parquet(['tables/verifications/part-000001.parquet'], union_by_name = true);
CREATE OR REPLACE VIEW runs_294b906e_1384_4a76_9ba5_b012745e1747 AS SELECT * FROM read_parquet(['searches/294b906e-1384-4a76-9ba5-b012745e1747/runs/part-000001.parquet']);
