# rc.3 test, Mac



- Feed: `rc-mac`, version -, made 2026-11-16T07:21:05Z
- Version id (manifest hash): `sha256:092bf24ebf79a4663ba905ccd04147f5ea9003df9bb70fdd44bf4fd77acf112d`
- Publisher key: `SHA256:h3TwxQOPru+J9oO61x3PHfwtdkXAjRd8//apVOc7jCY`
- Licence: CC0-1.0
- Creators: RC tester (Mac)

This is an export of a JETCARP pack (format jetcarp-pack 1.0). Every table is a Parquet
file under `tables/`, and `pack.json` is the manifest: its SHA-256 is the version id
above, and the indexes in `index/` give the SHA-256 of every file. The format is
described in the JETCARP book's *Pack format* reference.

## Tables

- `annotations`: 23 rows in 1 part
- `patterns`: 134 rows in 5 parts
- `provenance`: 134 rows in 1 part
- `rules`: 3 rows in 1 part
- `sightings`: 248 rows in 1 part
- `tilings`: 2 rows in 1 part
- `verifications`: 149 rows in 1 part
