-- DuckDB views over JETCARP pack version sha256:07b03d907a448c944b89a4a995844c4e4575ae4c3de749f108ab0a1f2cbd021d (feed rc-acer).
-- Not part of the format: run `duckdb -init views.sql` in this folder, or replace
-- the paths with this folder's URL to query a pack in place over HTTPS.
CREATE OR REPLACE VIEW annotations AS SELECT * FROM read_parquet(['tables/annotations/part-000001.parquet'], union_by_name = true);
CREATE OR REPLACE VIEW patterns AS SELECT * FROM read_parquet(['tables/patterns/class_group=oscillator/tiling_group=hex/part-000001.parquet', 'tables/patterns/class_group=oscillator/tiling_group=square/part-000001.parquet', 'tables/patterns/class_group=spaceship/tiling_group=square/part-000001.parquet', 'tables/patterns/class_group=still_life/tiling_group=hex/part-000001.parquet', 'tables/patterns/class_group=still_life/tiling_group=square/part-000001.parquet'], union_by_name = true);
CREATE OR REPLACE VIEW provenance AS SELECT * FROM read_parquet(['tables/provenance/part-000001.parquet'], union_by_name = true);
CREATE OR REPLACE VIEW rules AS SELECT * FROM read_parquet(['tables/rules/part-000001.parquet'], union_by_name = true);
CREATE OR REPLACE VIEW sightings AS SELECT * FROM read_parquet(['tables/sightings/part-000001.parquet'], union_by_name = true);
CREATE OR REPLACE VIEW tilings AS SELECT * FROM read_parquet(['tables/tilings/part-000001.parquet'], union_by_name = true);
CREATE OR REPLACE VIEW verifications AS SELECT * FROM read_parquet(['tables/verifications/part-000001.parquet'], union_by_name = true);
CREATE OR REPLACE VIEW runs_668eb340_e9e8_45b2_8eea_bcfe9df3be76 AS SELECT * FROM read_parquet(['searches/668eb340-e9e8-45b2-8eea-bcfe9df3be76/runs/part-000001.parquet']);
